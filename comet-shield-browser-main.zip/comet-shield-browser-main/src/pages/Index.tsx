import { BrowserWindow } from "@/components/browser/BrowserWindow";

const Index = () => {
  return <BrowserWindow />;
};

export default Index;
