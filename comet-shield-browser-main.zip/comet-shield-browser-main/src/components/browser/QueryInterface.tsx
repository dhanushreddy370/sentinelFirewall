import { useState } from "react";
import { motion } from "framer-motion";
import { Search, Paperclip, Globe, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export const QueryInterface = () => {
  const [query, setQuery] = useState("");

  const handleFileAttach = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        toast.info(`File attached: ${file.name}`);
      }
    };
    input.click();
  };

  const handleUrlAttach = () => {
    const url = prompt("Enter a URL to attach:");
    if (url) {
      toast.info(`URL attached: ${url}`);
    }
  };

  const handleSubmit = () => {
    if (query.trim()) {
      toast.success("Query submitted", {
        description: query,
      });
      setQuery("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="h-full flex items-center justify-center p-8">
      <motion.div
        className="w-full max-w-3xl glass-panel rounded-2xl p-6 space-y-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        whileHover={{ scale: 1.01 }}
      >
        {/* Textarea */}
        <Textarea
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask anything or enter a browsing command..."
          className="min-h-[200px] resize-none bg-transparent border-none text-base focus-visible:ring-0 focus-visible:ring-offset-0 placeholder:text-muted-foreground/50"
        />

        {/* Attachment Bar */}
        <div className="flex items-center justify-between pt-4 border-t border-border/30">
          {/* Left: Focus Button */}
          <Button
            variant="ghost"
            size="sm"
            className="gap-2"
            onClick={() => toast.info("Focus mode activated")}
          >
            <Search className="h-4 w-4" />
            Focus
          </Button>

          {/* Right: Action Icons */}
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleFileAttach}
              className="h-9 w-9"
            >
              <Paperclip className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleUrlAttach}
              className="h-9 w-9"
            >
              <Globe className="h-4 w-4" />
            </Button>
            <Button
              size="icon"
              onClick={handleSubmit}
              disabled={!query.trim()}
              className="h-9 w-9"
            >
              <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
