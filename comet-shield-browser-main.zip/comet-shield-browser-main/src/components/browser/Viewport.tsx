import { motion } from "framer-motion";
import { QueryInterface } from "./QueryInterface";

interface ViewportProps {
  shieldActive: boolean;
}

export const Viewport = ({ shieldActive }: ViewportProps) => {
  return (
    <motion.div
      className="h-full rounded-2xl bg-card border border-border overflow-hidden relative"
      animate={{
        borderColor: shieldActive
          ? "hsl(var(--shield-active))"
          : "hsl(var(--border))",
      }}
      transition={{ duration: 0.3 }}
    >
      {/* Central Query Interface */}
      <QueryInterface />

      {/* Glow effect when shield is active */}
      {shieldActive && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 pointer-events-none"
          style={{
            background: `radial-gradient(circle at 50% 50%, hsl(var(--glow-shield)) 0%, transparent 70%)`,
          }}
        />
      )}
    </motion.div>
  );
};
